package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn1 = findViewById(R.id.button);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }

    ProgressDialog dialog;
    CountDownTimer CDT;


    public void showDialog() {
        dialog = new ProgressDialog(this);
        dialog.setMessage("Please Wait...");

        dialog.show();

        CDT = new CountDownTimer(5000, 1000)
        {
            public void onTick(long millisUntilFinished)
            {

            }

            public void onFinish()
            {
                dialog.dismiss();
            }
        }.start();


//        TimerTask tt = new TimerTask() {
//            @Override
//            public void run() {
//                dialog.hide();
//            }
//        };
//
//        Timer t = new Timer();
//        t.schedule(tt, 0);
    }


}



